public class ContaBanco {
    public int numConta;
    protected String tipoConta;
    private String titular;
    private double saldo;
    private boolean status;

    public ContaBanco() {
        saldo = 0;
        status = false;
    }

    public int getNumConta() {
        return numConta;
    }

    public void setNumConta(int numConta) {
        this.numConta = numConta;
    }

    public String getTipoConta() {
        return tipoConta;
    }

    public void setTipoConta(String tipoConta) {
        if(tipoConta != "cp" && tipoConta != "cc") {
            throw new RuntimeException("Tipo de conta inválida! Digite cc para conta corrente e cp para conta poupança. ");
        }
        else {
            this.tipoConta = tipoConta;
        }
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public void abrirConta(String tipo) {
        setTipoConta(tipo);
        setStatus(true);

        if(tipo == "cp") {
            saldo += 150;
        }
        else {
            saldo += 50;
        }
        System.out.println("Conta aberta com sucesso. ");
    }
    public void fecharConta() {
        if(saldo > 0) {
            System.out.println("Conta com dinheiro. ");
        }
        else if(saldo < 0) {
            System.out.println("Conta em débito. ");
        }
        else {
            setStatus(false);
        }
        System.out.println("Conta fechada com sucesso. ");

    }

    public void depositar(double valorDeposito) {
        if(status && valorDeposito > 0) {
            saldo += valorDeposito;
            System.out.println("Valor depositado com sucesso! ");
        }
        else {
            System.out.println("Não foi possível efetuar o depósito! ");
        }
    }

    public void sacar(double valorSaque) {
        if(status && valorSaque <= saldo) {
            saldo -= valorSaque;
            System.out.println("Saque depositado com sucesso! ");
        }
        else {
            System.out.println("Não foi possível efetuar o saque! ");
        }
    }

    public void pagarMensal() {
        if(saldo <= 0) {
            System.out.println("Sem saldo! ");
        }
        else if(tipoConta == "cc" && saldo >= 12) {
            saldo -= 12;
            System.out.println("Mensalidade de 12 reais! ");
        } else if(tipoConta == "cp" && saldo >= 20) {
            saldo -= 20;
            System.out.println("Mensalidade de 20 reias");
        }
    }




}
